import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

// agent display
public class AgentPanel extends JPanel{

	private static final long serialVersionUID = 1L;
	
	private Agent agent;	// pointer to the agent
	
	// constructor
	public AgentPanel(Agent a){
		agent=a;
	}
	
	public void paintComponent(Graphics g){
		
		g.setColor(Color.white);
		g.fillRect(0,0, this.getWidth(), this.getHeight());
	}

	
}