
import java.util.ArrayList;


public class Agent extends Player{
	

	
	private AgentFrame display;
	
	public Agent(String name, int id, Main m){
		super(name, id,m);
		
		display=new AgentFrame(this);

	}
	
	public void initialize(){

	}
	
	public int update(int state, int reward, ArrayList<Integer> possible_actions){
		
		int actionIndex = (int)(Math.random()*possible_actions.size());
		
		return possible_actions.get( actionIndex );
	}
	
	
	public void learn(int state, int reward){
		
	}

	
}
