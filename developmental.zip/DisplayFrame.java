import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class DisplayFrame extends JFrame{

	private static final long serialVersionUID = 1L;

	private DisplayPanel panel;

	public DisplayFrame(Environment env){
		this.setTitle("Environment");
    	this.setSize(550, 650);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	panel=new DisplayPanel(env);
    	this.setContentPane(panel);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private class DisplayPanel extends JPanel  implements MouseListener{

		private static final long serialVersionUID = 1L;
		
		private Environment env;
		
		public Polygon triangle = new Polygon();

		
		public DisplayPanel(Environment e){
			env=e;
			addMouseListener(this);
			
			triangle.addPoint(25, 0);
			triangle.addPoint(-20,  20);
			triangle.addPoint(-20, -20);
		}
		
		public void paintComponent(Graphics g){
			
			
			// white background
			g.setColor(Color.white);
			g.fillRect(0,0, this.getWidth(), this.getHeight());
			
			// draw wall blocks
			g.setColor(new Color(0,128,0));
			for (int i=0;i<env.environment.length;i++){
				for (int j=0;j<env.environment[0].length;j++){
					if (env.environment[j][i]==1) g.fillRect(50*i, 50*j+80, 50, 50);
				}
			}
			
			// draw button
			if (env.pause) g.setColor(Color.gray);
			else g.setColor(Color.lightGray);
			g.fillRect(50, 10, 80, 50);
			
			if (env.step) g.setColor(Color.gray);
			else g.setColor(Color.lightGray);
			g.fillRect(150, 10, 80, 50);
			
			g.setColor(Color.black);
			g.drawString("pause", 72, 37);
			g.drawString("step",178, 37);
			
			// draw target
			g.setColor(new Color(150,100,255));
			g.fillOval(50*env.target[0], 50*(env.environment.length-1-env.target[1])+80, 50, 50);
			
			// draw trace
			g.setColor(Color.black);
			for (int i=0;i<env.trace.size()-1;i++){
				g.drawLine(50*env.trace.get(i  )[0]+25, 50*(env.environment.length-1-env.trace.get(i  )[1])+105,
						   50*env.trace.get(i+1)[0]+25, 50*(env.environment.length-1-env.trace.get(i+1)[1])+105);
			}
			
			// draw robot
			Graphics2D g2d = (Graphics2D)g;
			
			if (env.robot[5]==1) g.setColor(Color.red);
			else if (env.robot[5]==2) g.setColor(new Color(150,100,255));
			else g2d.setColor(Color.gray);
			
			AffineTransform position = new AffineTransform();
	        position.translate(env.robot[0]*50+25,(env.environment.length-1-env.robot[1])*50+25+80);
	        position.rotate(-env.robot[2]*Math.PI/2);
	        g2d.transform(position);
			
			g2d.fillPolygon(triangle);
			

			
		}

		public void mouseClicked(MouseEvent e) {
			// button events
			if (e.getX()>50 && e.getX()<130 && e.getY()>10 && e.getY()<60){
				env.pause=!env.pause;
			}
			else if (e.getX()>150 && e.getX()<230 && e.getY()>10 && e.getY()<60){
				env.step=true;
			}
			this.repaint();

		}
		public void mouseEntered(MouseEvent arg0) {}
		public void mouseExited(MouseEvent arg0) {}
		public void mousePressed(MouseEvent arg0) {}
		public void mouseReleased(MouseEvent arg0) {}
		
	}
}