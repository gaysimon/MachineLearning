import java.util.ArrayList;


public class Agent {
	
	public static int threshold=5;

	public ArrayList<Interaction> interList;
	
	public ArrayList<Interaction> timeline;

	
	private Interaction intendedScheme=null;
	private Interaction enactedScheme=null;
	
	
	private AgentFrame displayList;
	private DecisionFrame displayDecision;
	
	
	public Agent(Interaction[] list){
		
		interList=new ArrayList<Interaction>();
		for (int i=0;i<list.length;i++){
			interList.add(list[i]);
		}

		timeline=new ArrayList<Interaction>();
		
		
		displayList=new AgentFrame(this);
		displayDecision=new DecisionFrame(this);
	}
	
	
	
	// get intended primary interaction
	public Interaction intention(){
		
		int rand=(int)(Math.random()*interList.size());

		return interList.get(rand);
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////	
	public void setResult(Interaction enacted){
		
		// add to timeline
		timeline.add(0,enacted);
		while (timeline.size()>10) timeline.remove(timeline.size()-1);
		
		
		displayList.repaint();
		displayDecision.repaint();
	}
	
}
