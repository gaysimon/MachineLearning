import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class DecisionFrame extends JFrame{

	private static final long serialVersionUID = 1L;

	private AgentPanel panel;

	public DecisionFrame(Agent a){
		this.setTitle("Decision");
    	this.setSize(1000, 600);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	panel=new AgentPanel(a);
    	this.setContentPane(panel);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	private class AgentPanel extends JPanel{

		private static final long serialVersionUID = 1L;
		
		private Agent agent;
		
		private int[] lists;
		private int[] offsets;
		
		public AgentPanel(Agent a){
			agent=a;

			lists=new int[6];
			
			offsets=new int[6];
			offsets[0]=0;
			for (int i=1;i<6;i++) offsets[i]=offsets[i-1]+i*30+80;
		}
		
		public void paintComponent(Graphics g){
			
			
			// white background
			g.setColor(Color.white);
			g.fillRect(0,0, this.getWidth(), this.getHeight());
			
		
			// timeline
			g.setColor(Color.black);
			g.drawRect(5, 2, 80, 160);
			for (int i=0;i<agent.timeline.size();i++){
				g.drawString(agent.timeline.get(i).name, 20, 15+15*i);
			}
			
			// enaction timeline
			/*for (int i=0;i<agent.enactionLine.size();i++){
				g.drawString(agent.enactionLine.get(i).name, 200, 15+15*i);
			}*/
			
			
			// scopes
			/*for (int i=0;i<agent.scope2.size();i++){
				g.drawString(agent.scope2.get(i).name, 20, 200+15*i);
			}
			
			for (int i=0;i<agent.scope1.size();i++){
				g.drawString(agent.scope1.get(i).name, 320, 200+15*i);
			}*/
			
			
			// decision
			/*for (int i=0;i<agent.propositionList.size();i++){
				g.drawString(agent.propositionNb.get(i)+" : "+agent.propositionList.get(i).name, 600, 10+15*i);
			}
			
			for (int i=0;i<agent.propositionList.size();i++){
				g.drawString(""+agent.propositionValues.get(i), 680, 10+15*i);
			}*/
		}
	}
}