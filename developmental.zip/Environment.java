import java.util.ArrayList;

public class Environment {

	
	public int[][] environment;
	
	public int[] target;
	
	public int[] robot;	// [ px , py, r , distance , field , events ]
	
	public boolean pause=true;
	public boolean step=false;
	
	public ArrayList<int[]> trace;
	
	public Environment(){
		
		environment=new int[][]{
				{1,1,1,1,1,1,1,1,1,1},
				{1,0,0,0,0,0,0,0,0,1},
				{1,0,0,0,0,0,0,0,0,1},
				{1,0,0,0,0,0,0,0,0,1},
				{1,0,0,0,0,0,0,0,0,1},
				{1,0,0,0,0,0,0,0,0,1},
				{1,0,0,0,0,0,0,0,0,1},
				{1,0,0,0,0,0,0,0,0,1},
				{1,0,0,0,0,0,0,0,0,1},
				{1,1,1,1,1,1,1,1,1,1} 
				};
	
		target=new int[]{4,5};
		
		robot=new int[]{5,2,1,-1,-1,0};
	
		trace=new ArrayList<int[]>();
	}
	
	public int intend(Interaction intended){          
		
		int enacted=-1;
		robot[5]=0;
		
		// move the agent forward
		if (intended.name.charAt(0)=='>' || intended.name.charAt(0)=='X' || intended.name.charAt(0)=='E'){

			// detect obstacle
			if ((robot[2]==0 && environment[robot[0]+1][robot[1]]==1)		// >
			 || (robot[2]==1 && environment[robot[0]][robot[1]+1]==1)		// ^
			 || (robot[2]==2 && environment[robot[0]-1][robot[1]]==1)		// <
			 || (robot[2]==3 && environment[robot[0]][robot[1]-1]==1)		// v
			 ){
				enacted=1; // bump
				robot[5]=1;
			}
			else{
				
				// move forward
				if (robot[2]==0) robot[0]++;
				if (robot[2]==1) robot[1]++;
				if (robot[2]==2) robot[0]--;
				if (robot[2]==3) robot[1]--;
				
				
				// detect eat
				if (robot[0]==target[0] && robot[1]==target[1]){
					
					while (target[0]==robot[0] || target[1]==robot[1] || environment[target[0]][target[1]]!=0 ){
						target[0]=(int)(Math.random()*10);
						target[1]=(int)(Math.random()*10);	
					}
					enacted=2;  // eat
					robot[5]=2;
				}
				else{
					
					if (target[0]==-1){	// target not visible
						robot[3]=-1;
						enacted=0;
					}
					else{
						// detect target
						int previous_distance=robot[3];
						int previous_area=robot[4];
						
						detect();
						
						if (previous_distance==-1 && robot[3]>=0){	   // appearance
							if (robot[4]==2) enacted=6;
							if (robot[4]==0) enacted=7;
							if (robot[4]==1) enacted=8;
						}
						else if (previous_distance>=0 && robot[3]==-1){	   // disappearance
							if (previous_area==2) enacted=9;
							if (previous_area==0) enacted=10;
							if (previous_area==1) enacted=11;
						}
						else if (robot[3]>=0 && robot[3]<previous_distance){ // approach
							if (robot[4]==2) enacted=3;
							if (robot[4]==0) enacted=4;
							if (robot[4]==1) enacted=5;
						}
						else enacted=0; // forward
					}
				}
			}
		}
		else if (intended.name.charAt(0)=='^'){
		
			// rotate left
			robot[2]++;
			if (robot[2]>3) robot[2]=0;
			
			
			if (target[0]==-1){	// target not visible
				robot[3]=-1;
				enacted=12;
			}
			else{
				
				// detect target
				int previous_distance=robot[3];
				int previous_area=robot[4];
				
				detect();
				
				if ((previous_distance==-1 || previous_area!=robot[4]) && robot[3]>=0){	   // appearance
					if (robot[4]==2) enacted=17;
					if (robot[4]==0) enacted=18;
					if (robot[4]==1) enacted=19;
				}
				else if (previous_distance>=0 && robot[3]==-1){	   // disappearance
					if (previous_area==2) enacted=20;
					if (previous_area==0) enacted=21;
					if (previous_area==1) enacted=22;
				}
				else if (robot[3]>=0 && robot[3]<previous_distance){ // approach
					if (robot[4]==2) enacted=14;
					if (robot[4]==0) enacted=15;
					if (robot[4]==1) enacted=16;
				}
				else enacted=12; // ^
				
			}
			
		}
		else if (intended.name.charAt(0)=='v'){
			
			// rotate right
			robot[2]--;
			if (robot[2]<0) robot[2]=3;
			
			
			if (target[0]==-1){	// target not visible
				robot[3]=-1;
				enacted=13;
			}
			else{

				// detect target
				int previous_distance=robot[3];
				int previous_area=robot[4];
				
				detect();
				
				if ((previous_distance==-1 || previous_area!=robot[4]) && robot[3]>=0){	   // appearance
					if (robot[4]==2) enacted=26;
					if (robot[4]==0) enacted=27;
					if (robot[4]==1) enacted=28;
				}
				else if (previous_distance>=0 && robot[3]==-1){	   // disappearance
					if (previous_area==2) enacted=29;
					if (previous_area==0) enacted=30;
					if (previous_area==1) enacted=31;
				}
				else if (robot[3]>=0 && robot[3]<previous_distance){ // approach
					if (robot[4]==2) enacted=23;
					if (robot[4]==0) enacted=24;
					if (robot[4]==1) enacted=25;
				}
				else enacted=13; // v
			}
		}
		
		trace.add(robot.clone());
		if (trace.size()>20) trace.remove(0);
		
		return enacted;
	}
	
	
	private void detect(){
		
		// detect target
		robot[3]=-1;
		robot[4]=-1;
		
		// left eye
		if ( (robot[2]==0 && target[0]>=robot[0] && target[1]>=robot[1])	// >
		  || (robot[2]==1 && target[0]<=robot[0] && target[1]>=robot[1])	// ^
		  || (robot[2]==2 && target[0]<=robot[0] && target[1]<=robot[1])	// <
		  || (robot[2]==3 && target[0]>=robot[0] && target[1]<=robot[1])	// v
		){
			robot[4]+=1;
		}
		
		// right eye
		if ( (robot[2]==0 && target[0]>=robot[0] && target[1]<=robot[1])	// >
		  || (robot[2]==1 && target[0]>=robot[0] && target[1]>=robot[1])	// ^
		  || (robot[2]==2 && target[0]<=robot[0] && target[1]>=robot[1])	// <
		  || (robot[2]==3 && target[0]<=robot[0] && target[1]<=robot[1])	// v
		){
			robot[4]+=2;
		}
		
		
		if (robot[4]>=0){
			robot[3]=(int)(Math.sqrt( (target[0]-robot[0])*(target[0]-robot[0]) 
									+ (target[1]-robot[1])*(target[1]-robot[1]) )*100 );
		}
		else robot[3]=-1;
	}
	
}
