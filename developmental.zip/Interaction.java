import java.util.ArrayList;


public class Interaction {


	
	public String name="";
	public int valence=0;
	
	public int enactions=1;	// count enactions
	
	
	public Interaction(String n, int val){
		name=n;
		valence=val;
	}
	
	
	public boolean isEqual(Interaction inter){
		return this.name.equals(inter.name);
	}
	
	public int isIncluded(ArrayList<Interaction> list){
		
		boolean found=false;
		int i=0;
		
		while (!found && i<list.size()){
			if (this.isEqual(list.get(i))) found=true;
			else i++;
		}
		if (!found) i=-1;
		
		return i;
	}
}
