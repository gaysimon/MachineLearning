


public class Main {

	
	
	public static void main(String[] args) {
		
		Environment env=new Environment();
		
		// define list of interactions
		Interaction[] list=new Interaction[32];
		list[ 0]=new Interaction(">  " ,0);
		list[ 1]=new Interaction("X  ",-10);
		list[ 2]=new Interaction("E  ",50);
		
		list[ 3]=new Interaction(">+C",5);
		list[ 4]=new Interaction(">+L",5);
		list[ 5]=new Interaction(">+R",5);
		
		list[ 6]=new Interaction(">*C",5);
		list[ 7]=new Interaction(">*L",5);
		list[ 8]=new Interaction(">*R",5);
		
		list[ 9]=new Interaction(">-C",-5);
		list[10]=new Interaction(">-L",-5);
		list[11]=new Interaction(">-R",-5);
		
		
		list[12]=new Interaction("^  ",-1);
		list[13]=new Interaction("v  ",-1);
		
		
		list[14]=new Interaction("^+C",5);
		list[15]=new Interaction("^+L",5);
		list[16]=new Interaction("^+R",5);
		
		list[17]=new Interaction("^*C",0);
		list[18]=new Interaction("^*L",0);
		list[19]=new Interaction("^*R",0);
		
		list[20]=new Interaction("^-C",-5);
		list[21]=new Interaction("^-L",-5);
		list[22]=new Interaction("^-R",-5);
		
		
		list[23]=new Interaction("v+C",5);
		list[24]=new Interaction("v+L",5);
		list[25]=new Interaction("v+R",5);
		
		list[26]=new Interaction("v*C",0);
		list[27]=new Interaction("v*L",0);
		list[28]=new Interaction("v*R",0);
		
		list[29]=new Interaction("v-C",-5);
		list[30]=new Interaction("v-L",-5);
		list[31]=new Interaction("v-R",-5);
		
	
		Agent agent=new Agent(list);
		
		
		DisplayFrame display=new DisplayFrame(env);
		
		
		// start agent-environment interaction cycle
		
		Interaction intended;
		Interaction enacted;
		
		display.repaint();
		
		try {Thread.sleep(500);}
		catch (InterruptedException e) {e.printStackTrace();}
		
		while (true){
			
			// gestion de la pause et du pas-�-pas
			while (env.pause && !env.step){
				try {Thread.sleep(20);}
				catch (InterruptedException e) {e.printStackTrace();}
			}
			env.step=false;
			
			intended=agent.intention();
			System.out.print(intended.name);
			
			enacted=list[env.intend(intended)];
			System.out.println(" -> "+enacted.name);
			agent.setResult(enacted);
			
			display.repaint();
			
			try {Thread.sleep(50);}
			catch (InterruptedException e) {e.printStackTrace();}
		}
		
	}

}
