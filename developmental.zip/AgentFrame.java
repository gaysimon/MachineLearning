import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class AgentFrame extends JFrame{

	private static final long serialVersionUID = 1L;

	private AgentPanel panel;

	public AgentFrame(Agent a){
		this.setTitle("Scheme list");
    	this.setSize(1200, 800);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	panel=new AgentPanel(a);
    	this.setContentPane(panel);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	private class AgentPanel extends JPanel{

		private static final long serialVersionUID = 1L;
		
		private Agent agent;
		
		private int[] lists;
		private int[] offsets;
		
		public AgentPanel(Agent a){
			agent=a;

			lists=new int[6];
			
			offsets=new int[6];
			offsets[0]=0;
			for (int i=1;i<6;i++) offsets[i]=offsets[i-1]+i*30+80;
		}
		
		public void paintComponent(Graphics g){
			
			
			// white background
			g.setColor(Color.white);
			g.fillRect(0,0, this.getWidth(), this.getHeight());
			
			// list interactions
			/*for (int i=0;i<6;i++) lists[i]=0;
			g.setColor(Color.black);
			for (int i=0;i<agent.interList.size();i++){
				if (agent.interList.get(i).length>=6){
					g.drawString(agent.interList.get(i).name+" , ("
									+agent.interList.get(i).valence+") : "
									+agent.interList.get(i).enactions,
									20+offsets[5], 10+12*lists[5]);
					
					lists[5]++;
					for (int j=0;j<agent.interList.get(i).alternativeList.size();j++){
						g.drawString("     "+agent.interList.get(i).alternativeList.get(j).name+" : ",
								            30+offsets[5], 15+12*lists[5]);
						lists[5]++;
					}
				}
				else{
					g.drawString(agent.interList.get(i).name+" , ("
								+agent.interList.get(i).valence+") : "
								+agent.interList.get(i).enactions,
								20+offsets[agent.interList.get(i).length-1], 10+12*lists[agent.interList.get(i).length-1]);
					
					lists[agent.interList.get(i).length-1]++;
					for (int j=0;j<agent.interList.get(i).alternativeList.size();j++){
						g.drawString("     "+agent.interList.get(i).alternativeList.get(j).name+" : ",
											30+offsets[agent.interList.get(i).length-1], 10+12*lists[agent.interList.get(i).length-1]);
						lists[agent.interList.get(i).length-1]++;
					}
				}
			}*/
		}
	}
}