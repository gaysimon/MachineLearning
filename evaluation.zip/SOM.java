
public class SOM {

	//public Neuron[][] map;		// neuron map
	
	public static int size=20;	// size of the map (sizeXsize)
	
	public int imin=0;			// coordinates of best neuron
	public int jmin=0;
	
	public SOM(){
		
		// initialize map
		/*map=new Neuron[size][size];
		for (int i=0;i<size;i++){
			for (int j=0;j<size;j++){
				map[i][j]=null;
			}
		}*/
	}
	
	
	public void compute(float[] img){
		
		// TODO : compute all neurons values
		
		
		
		// TODO : find neuron with minimum distance

		
		
		// TODO (for growing SOM) : add new neurons
		
		
		
		// TODO : update neurons' weights

		
		
		
	}
	
	
	// neighboring function
	public float neighbor(float x){
		return (float)Math.exp(-x/(8));
	}
	
}
