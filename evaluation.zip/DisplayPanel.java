import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JPanel;


public class DisplayPanel extends JPanel implements MouseMotionListener{

	private static final long serialVersionUID = 1L;
	
	private Main main;
	
	// position of neuron selected with cursor
	public int px=0;
	public int py=0;
	
	
	public DisplayPanel(Main m){
		main=m;
		this.addMouseMotionListener(this);
	}
	
	public void paintComponent(Graphics g){
		
		// background
		g.setColor(Color.white);
		g.fillRect(0,0, this.getWidth(), this.getHeight());
		
		// draw the current dataset image
		int val=0;
		for (int i=0;i<Main.size_x;i++){
			for (int j=0;j<Main.size_y;j++){
				val=(int)(main.matrixImages[main.test][i+Main.size_x*j]*255);
				g.setColor(new Color(val,val,val));
				g.fillRect(10+5*i, 10+5*j, 5, 5);
			}
		}
		
		// draw the SOM map activity
		// TODO : uncomment after creating Neuron class
		/*for (int i=0;i<SOM.size;i++){
			for (int j=0;j<SOM.size;j++){
				if (main.som.map[i][j]!=null){
					val=255-(int)(main.som.map[i][j].output*255)*20;
					if (val>255) val=255;
					if (val<0) val=0;
					//val=(255-val);
					g.setColor(new Color(val,val,val));
					g.fillRect(200+10*i, 10+10*j, 10, 10);
				}
				else{
					g.setColor(Color.blue);
					g.fillRect(200+10*i, 10+10*j, 10, 10);
				}
			}
		}*/
		
		// draw position of the most active neuron
		g.setColor(Color.red);
		g.drawRect(200+10*main.som.imin, 10+10*main.som.jmin, 10, 10);
		
		
		// draw the weights of the neuron selected with cursor
		// TODO : uncomment after creating Neuron class
		/*if (main.som.map[px][py]!=null){
			for (int i=0;i<Main.size_x;i++){
				for (int j=0;j<Main.size_y;j++){
					int id=Main.size_x*j+i;
					val=(int)(main.som.map[px][py].synaps[id]*255);
					g.setColor(new Color(val,val,val));
					g.fillRect(10+5*i, 200+5*j, 5, 5);
				}
			}
		}*/
		
	}

	// unused
	public void mouseDragged(MouseEvent arg0) {}

	// selection of a neuron by moving mouse cursor on the map
	public void mouseMoved(MouseEvent e) {
		if (e.getX()>=200 && e.getX()<200+SOM.size*10 && e.getY()>=10 && e.getY()<10+SOM.size*10){
			px=(e.getX()-200)/10;
			py=(e.getY()- 10)/10;
		}
		
	}
	
}
