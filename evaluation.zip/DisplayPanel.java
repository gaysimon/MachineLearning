import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;


public class DisplayPanel extends JPanel{

	private static final long serialVersionUID = 1L;
	
	private Main main;
	
	public DisplayPanel(Main m){
		main=m;
	}
	
	public void paintComponent(Graphics g){
		
		// fond blanc
		g.setColor(Color.white);
		g.fillRect(0,0, this.getWidth(), this.getHeight());
		
		
		// affichage de l'image d'entr�e
		g.setColor(Color.black);
		g.drawString("input image", 5, 12);
		
		int val=0;
		for (int i=0;i<Main.size_x;i++){
			for (int j=0;j<Main.size_y;j++){
				val=(int)(main.img[i][j]*255);
				g.setColor(new Color(val,val,val));
				g.fillRect(5+i, 20+j, 1, 1);
			}
		}
		
		
		// affichage de l'image d'entrainement
		g.setColor(Color.black);
		g.drawString("training image", 5, 248);
		
		for (int i=0;i<Main.size_x-4;i++){
			for (int j=0;j<Main.size_y-4;j++){
				val=(int)(main.output[i][j]*255/4)+128;
				if (val>255) val=255;
				if (val<0) val=0;
				g.setColor(new Color(val,val,val));
				g.fillRect(5+i, 250+j, 1, 1);
			}
		}
		
		
		// affichage du noyau de convolution du neurone
		g.setColor(Color.black);
		g.drawString("convolution", 250, 52);
		
		for (int i=0;i<5;i++){
			for (int j=0;j<5;j++){
				val=(int)(main.neuron.synaps[j][i]*255/4)+128;
				if (val>255) val=255;
				if (val<0) val=0;
				g.setColor(new Color(val,val,val));
				g.fillRect(250+20*i, 60+20*j, 20, 20);
			}
		}
		
		
		// affichage de l'image de sortie
		g.setColor(Color.black);
		g.drawString("output image", 400, 12);
		
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		// faire pointer output sur l'image de sortie de votre neurone
		float[][] output=new float[Main.size_x-4][Main.size_y-4];
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		for (int i=0;i<Main.size_x-4;i++){
			for (int j=0;j<Main.size_y-4;j++){
				val=(int)((output[i][j]*255/4)+128);
				if (val>255) val=255;
				if (val<0) val=0;
				g.setColor(new Color(val,val,val));
				g.fillRect(400+i, 22+j, 1, 1);
			}
		}
		
		
		// affichage du delta
		g.setColor(Color.black);
		g.drawString("delta", 400, 248);
		
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		// faire pointer delta sur l'image Delta de votre neurone
		float[][] delta=new float[Main.size_x-4][Main.size_y-4];
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		for (int i=0;i<Main.size_x-4;i++){
			for (int j=0;j<Main.size_y-4;j++){
				val=(int)((delta[i][j]*255/4)+128);
				if (val>255) val=255;
				if (val<0) val=0;
				g.setColor(new Color(val,val,val));
				g.fillRect(400+i, 250+j, 1, 1);
			}
		}
	}
	
	
	
}
