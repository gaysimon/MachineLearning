
public class Neuron {

	public float learnRate=0.05f/(Main.size_x*Main.size_y);
	
	public float[][] synaps;	// kernel de convolution
	
	public float[][] output;	// image de sortie du neurone
	
	public float[][] delta;		// delta entre l'image de test et de sortie
	
	
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	// compl�tez les fonctions
	public Neuron(){
		synaps=new float[5][5];
		
	}
	
	// fonction pour calculer l'image de sortie
	public void compute(float[][] img){
		
	}
	
	// fonction pour mettre � jour les poids
	public void learn(float[][] img, float res[][]){
		

	}
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
}
