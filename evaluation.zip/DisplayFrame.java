import javax.swing.JFrame;


public class DisplayFrame extends JFrame{

	private static final long serialVersionUID = 1L;

	private DisplayPanel panel;

	public DisplayFrame(Main m){
		this.setTitle("Convolutional");
    	this.setSize(620, 550);
    	this.setLocationRelativeTo(null);               
    	this.setVisible(true);
    	panel=new DisplayPanel(m);
    	this.setContentPane(panel);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}