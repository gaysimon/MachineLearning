import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Main {

	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	// �ditez le chemin vers le fichier imgs
	public static String PATH="./img/";
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	private DisplayFrame display;
	private BufferedImage image=null;
	
	public static int size_x=200;
	public static int size_y=200;
	
	public float[][] img;
	public float[][] output;
	
	
	public Neuron neuron;	// pointeur vers votre neurone
	
	
	// fonction principale de l'apprentissage
	public Main(){
		
		////////////////////////////////////////////////////////////////////////////
		neuron=new Neuron();	// modifiez seulement si vous ajoutez des param�tres
		////////////////////////////////////////////////////////////////////////////
		
		
		img=new float[size_x][size_y];
		output=new float[size_x-4][size_y-4];
		
		display=new DisplayFrame(this);
		
		// boucle des epochs
		for (int epoch=0;epoch<100;epoch++){
			
			// boucle de lecture des 10 images
			for (int n=1;n<=10;n++){
			
				if (n<10) loadImage("00"+n+".png");
				else loadImage("0"+n+".png");
				
				////////////////////////////////////////////////////////////////////////////
				// appel � vos fonctions de calcul et de mise � jour (rien � faire)
				neuron.compute(img);
				
				neuron.learn(img, output);
				
				////////////////////////////////////////////////////////////////////////////
				
				display.repaint();
				try {Thread.sleep(10);
				} catch (InterruptedException e) {e.printStackTrace();}
			}
		}
	}
	
	
	
	////////////////////////////////////////////////////
	// fonction utilitaire pour le chargement des images
	public void loadImage(String name){
		System.out.println(name);
		
		try {
			image=ImageIO.read(new File(PATH+"input/"+name));
		} catch (IOException e) {e.printStackTrace();}
		
		
		for (int i=0;i<size_x;i++){
			for (int j=0;j<size_y;j++){
				img[i][j]=(((float)((image.getRGB(i,j)>> 16) & 0x000000FF))/255
						  +((float)((image.getRGB(i,j)>>  8) & 0x000000FF))/255
						  +((float)((image.getRGB(i,j)     ) & 0x000000FF))/255)/3;
			}
		}
		
		try {
			image=ImageIO.read(new File(PATH+"output/"+name));
		} catch (IOException e) {e.printStackTrace();}
		
		
		for (int i=0;i<size_x-4;i++){
			for (int j=0;j<size_y-4;j++){
				output[i][j]=(((float)((image.getRGB(i,j)>> 16) & 0x000000FF))/255
						  +((float)((image.getRGB(i,j)>>  8) & 0x000000FF))/255
						  +((float)((image.getRGB(i,j)     ) & 0x000000FF))/255)/3-0.5f;
				
				output[i][j]=output[i][j]*4;
			}
		}
	}
	
	/////////////////////////////
	// fonction main du programme
	public static void main(String[] args) {
		new Main();
	}

}
