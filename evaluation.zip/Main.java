import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class Main {

	// path to images
	// TODO : set path to your dataset folder
	public static String PATH="";	
	
	
	public static int size_x=28;	// size of the image (set when image is loaded
	public static int size_y=28;
	
	public float[][] matrixImages; // matrix containing the dataset
	
	public int epoch=0;
	public int test=0;
	
	// self organizing map
	public SOM som;
	
	// displayer
	private DisplayFrame display;
	
	public Main(){
		
		// load dataset (TODO : check the path)
		setData("numbers\\train-images.idx3-ubyte");
		//setData("fashion\\train-images-idx3-ubyte");
		
		// initialize self-organizing map
		som=new SOM();
		
		// initialize display frame
		display=new DisplayFrame(this);
		
		
		// you can increase number of epoch here
		for (int epoch=0;epoch<1;epoch++){
			
			for (test=0;test<matrixImages.length;test++){
			
				som.compute(matrixImages[test]); // compute the self-organizing map
				
				if (test%1000==0) System.out.println(test);	
				display.repaint();
			}
			test=0;
		}
	}
	
	// function to load a dataset
	public void setData(String fileImg){
		try {
			DataInputStream dataFile = new DataInputStream(
												new BufferedInputStream(
												   new FileInputStream(PATH+"MNIST\\"+fileImg)));
			
			int magicNumber = dataFile.readInt();
	        int nbImages = dataFile.readInt();
	        size_y = dataFile.readInt();
	        size_x = dataFile.readInt();

	        System.out.println("magic number is " + magicNumber);
	        System.out.println("number of items is " + nbImages);
	        System.out.println("number of rows is: " + size_y);
	        System.out.println("number of cols is: " + size_x);
	        
	        int nbPixels=size_x*size_y;
	        matrixImages=new float[nbImages][nbPixels];
	        
	        for (int i=0;i<nbImages;i++){
	        	for (int j=0;j<nbPixels;j++){
	        		matrixImages[i][j]=((float)dataFile.readUnsignedByte())/255;
	        	}
	        }
	        
	        dataFile.close();
		
		} catch (IOException e) {System.out.print(e);}
		
	}
	
	////////////////////////////////////////
	public static void main(String[] args) {
		new Main();
	}

}
